



import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_toggle_tab/flutter_toggle_tab.dart';
import 'package:flutter/material.dart';
import 'package:income/Card.dart';
import 'main.dart';

class screen2 extends StatelessWidget {
  const screen2({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter app',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        scaffoldBackgroundColor: Color(0xff00734E),
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),

    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var ind = 0;
 var c= new Crd("Enkhmunkh Nyamdorj", "6245 7894 1233 7894", "789", "06/30", "07/40");
  bool vis=true;
  var r=0;
  var col=[Colors.black54,Colors.black54,Colors.black54];
  Widget radd(double s,int v){
    return Container(
        width: s,
        child: Transform.scale(
          scale: 1.4,
          child: Radio(
            activeColor: Color(0xff00734E),
            value: v,
            groupValue: r,
            onChanged: (int? value) {
              setState(() {
                r = value!;
                rad(r);
              });
            },


          ),
        ),
      );
  }
  var x="";
  void rad(int i){
    setState(() {
      r=i;
      switch(r){
        case 1:setState(() {
            col=[Color(0xff00734E),Colors.black54,Colors.black54];
        }); break;
        case 2:setState(() {
          col=[Colors.black54,Color(0xff00734E),Colors.black54];
        });break;
        case 3:setState(() {
          col=[Colors.black54,Colors.black54,Color(0xff00734E)];
        });break;
      }
    });
  }
  @override
  Widget build(BuildContext context) {


    return Scaffold(

        body: SingleChildScrollView(
          child: Center(
            // Center is a
            // layout widget. It takes a single child and positions it
            // in the middle of the parent.
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height*0.17,

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children:  [
                      IconButton(
                          onPressed: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()  ),);
                                    },
                          icon: Icon(Icons.arrow_back,color: Colors.white,)),
                      Text("Connect Wallet",style: TextStyle(fontSize: 20,color: Colors.white),),
                      IconButton(onPressed: (){}, icon: Icon(Icons.notifications_none,color: Colors.white,))
                    ],
                  ),
                ),
                Container(
                height: MediaQuery.of(context).size.height*0.82,
                  width: MediaQuery.of(context).size.width,
                  child: Container(
                    decoration:  const BoxDecoration(
                      borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10)),
                      color: Colors.white,
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          SizedBox(
                            height: 22,
                          ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: MediaQuery.of(context).size.width,
                                child: FlutterToggleTab(
                                  borderRadius: 30,
                                  unSelectedBackgroundColors: const [Colors.white54],
                                  height: 50,
                                  marginSelected:  const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                                  isShadowEnable: true,
                                  selectedIndex: ind,
                                  selectedBackgroundColors: const [Colors.white30],
                                  labels:  const ['Cards','Accounts'],
                                  selectedLabelIndex: (index){
                                    setState(() {
                                      ind=index;
                                      print(index);
                                      (index==0)?vis=true:vis=false;
                                    });
                                  },
                                  selectedTextStyle: const TextStyle(color: Colors.black),
                                  unSelectedTextStyle: const TextStyle(color: Colors.black),

                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Visibility(
                            visible: vis,
                            child: Row(

                              children: [
                                Container(

                                    width: MediaQuery.of(context).size.width,
                                    child: Container(

                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.center ,
                                            children: [
                                              Container(
                                                width: MediaQuery.of(context).size.width*0.9,
                                                height: (MediaQuery.of(context).size.width*0.9)/1.59 ,
                                                decoration:  BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage("images/card.png"),
                                                    fit: BoxFit.contain,
                                                  ),
                                                ),
                                                child: Column(
                                                  children: [
                                                    Row(
                                                      children:  [
                                                        SizedBox(
                                                          height: MediaQuery.of(context).size.width/3,
                                                        )
                                                      ],
                                                    ),
                                                    Row(
                                                      children: [
                                                        Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Row(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              children: [
                                                                SizedBox(
                                                                  width: 50,
                                                                ),
                                                                Text(c.cardno,style: TextStyle(fontSize: 22,letterSpacing: 1,wordSpacing: 5,color: Colors.white) ,)
                                                              ],
                                                            ),
                                                            Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              children: [
                                                                SizedBox(
                                                                  width: 50,
                                                                ),
                                                                Container(
                                                                  width:30,
                                                                  child: Text("VALID FROM",style: TextStyle(color: Colors.white,fontSize: 7)),
                                                                ),
                                                                Text(c.val_date,style: TextStyle(color: Colors.white,fontSize: 16),),
                                                                SizedBox(width: 10,),
                                                                Container(
                                                                  width: 30,
                                                                  child: Text("GOOD THRU",style: TextStyle(color: Colors.white,fontSize: 7)),
                                                                ),
                                                                Text(c.exp_date,style: TextStyle(color: Colors.white,fontSize: 16),),
                                                                SizedBox(width: 100,)
                                                              ],
                                                            ),
                                                            Row(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              children: [
                                                                SizedBox(
                                                                  width: 30,
                                                                ),
                                                                Column(
                                                                  children: [
                                                                    SizedBox(
                                                                      height: 010,
                                                                    ),

                                                                    Row(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      children: [
                                                                        SizedBox(
                                                                          width: 10,
                                                                        ),
                                                                        Text(c.name,style: TextStyle(color: Colors.white,fontSize: 18,wordSpacing: 10),),

                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),

                                                              ],
                                                            )
                                                          ],
                                                        )
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 20,
                                          ),
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    width: MediaQuery.of(context).size.width*0.9,
                                                    height: 40,
                                                    child: TextFormField(
                                                      decoration: InputDecoration(
                                                        border: OutlineInputBorder(),
                                                        labelText: "Card number",
                                                      ),

                                                      keyboardType:TextInputType.number,
                                                      onChanged: (text){
                                                        setState((){
                                                          c.cardno=text;

                                                        });
                                                      },
                                                    ),
                                                  )
                                                ],
                                              ),
                                              SizedBox(
                                                height: 20,
                                              ),
                                              Container(
                                                width: MediaQuery.of(context).size.width,
                                                height: 40,
                                                decoration: BoxDecoration(

                                                  border: Border(),
                                                ),

                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      height: 40,
                                                      width: MediaQuery.of(context).size.width*0.3,
                                                      child: TextFormField(
                                                        decoration: InputDecoration(
                                                          border: OutlineInputBorder(),
                                                          labelText: "Expiration date",
                                                        ),
                                                        keyboardType:TextInputType.text,

                                                        onChanged: (text){
                                                          setState(() {
                                                            c.exp_date=text;
                                                          });
                                                        },
                                                      ),
                                                    ),
                                                    Container(
                                                      height: 40,
                                                      width: MediaQuery.of(context).size.width*0.3,
                                                      child: TextFormField(
                                                        decoration: InputDecoration(
                                                          border: OutlineInputBorder(),
                                                          labelText: "Validation date",
                                                        ),
                                                        keyboardType:TextInputType.text,

                                                        onChanged: (text){
                                                          setState(() {
                                                            c.val_date=text;
                                                          });
                                                        },
                                                      ),
                                                    ),
                                                    Container(
                                                      height: 40,
                                                      width: MediaQuery.of(context).size.width*0.3,
                                                      child: TextFormField(
                                                        keyboardType:TextInputType.number,
                                                        obscureText: true,
                                                        decoration: InputDecoration(
                                                          border: OutlineInputBorder(),
                                                          labelText: "CVC",
                                                        ),
                                                        onChanged: (text){
                                                          setState(() {
                                                            c.cvc=text;
                                                          });
                                                        },
                                                      ),
                                                    ),

                                                  ],
                                                ),

                                              ),
                                              SizedBox(height: 20,),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    width: MediaQuery.of(context).size.width*0.9,
                                                    height: 40,
                                                    child: TextFormField(
                                                      keyboardType:TextInputType.text,
                                                      decoration: InputDecoration(
                                                        border: OutlineInputBorder(),
                                                        labelText: "Name",
                                                      ),

                                                      onChanged: (text){
                                                        setState(() {
                                                          c.name=text.toUpperCase();
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(
                                                height: 20,
                                              ),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [

                                                  Container(
                                                    width: MediaQuery.of(context).size.width*0.9,


                                                    child: OutlinedButton(

                                                        onPressed: () {  },
                                                        style:ButtonStyle(
                                                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),side: BorderSide(color:Color(0xff00734E), ), ))    ,

                                                        ),
                                                        child: Text("Save",style: TextStyle(color:Color(0xff00734E),fontSize: 16),),

                                                    ) ,
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),


                                        ],
                                      ),
                                    ),
                                ),
                              ],
                            ),
                            replacement: Container(
                              width: MediaQuery.of(context).size.width,
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    Container(
                                      height: 140,
                                      width: MediaQuery.of(context).size.width*0.9,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.circular(10)),
                                        color: Colors.black12,
                                      ),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            width: 18,
                                          ),
                                          Container(
                                            width:90,
                                            height: 90,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Colors.white
                                            ),
                                            child: Icon(Icons.house_siding_rounded,size:50 ,color: col[0]),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            width: 180,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text("Bank Link",style: TextStyle(fontSize: 22,color: col[0]),),
                                                Text("Connect your bank account to deposit & fund",style: TextStyle(fontSize: 15,color: col[0],),softWrap: true,),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          radd(12,1),
                                        ],
                                      ),
                                    ),
                                    /*--------------------------------------------------------------------------------------------------------------------------------------------------*/

                                    SizedBox(
                                      height: 20,
                                    ),
                                    Container(
                                      height: 140,
                                      width: MediaQuery.of(context).size.width*0.9,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.circular(10)),
                                        color: Colors.black12,
                                      ),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            width: 18,
                                          ),
                                          Container(
                                            width:90,
                                            height: 90,
                                            decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.white
                                            ),
                                            child: Icon(Icons.monetization_on_rounded,size:50 ,color: col[1]),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            width: 180,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text("MicroDeposit",style: TextStyle(fontSize: 22,color: col[1]),),
                                                Text("Connect bank in 5-7 days",style: TextStyle(fontSize: 15,color: col[1],),softWrap: true,),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          radd(12,2),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
/*--------------------------------------------------------------------------------------------------------------------------------------------------*/
                                    Container(

                                      height: 140,
                                      width: MediaQuery.of(context).size.width*0.9,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.circular(10)),
                                        color: Colors.black12,
                                      ),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            width: 18,
                                          ),
                                          Container(
                                            width:90,
                                            height: 90,
                                            decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.white
                                            ),
                                            child: Icon(Icons.paypal_rounded,size:50 ,color: col[2]),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            width: 180,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text("Bank Link",style: TextStyle(fontSize: 22,color: col[2]),),
                                                Text("Connect your bank account to deposit &fund",style: TextStyle(fontSize: 15,color: col[2],),softWrap: true,),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          radd(12, 3),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 20,),

                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [

                                        Container(
                                          width: MediaQuery.of(context).size.width*0.9,
                                          child: OutlinedButton(
                                            onPressed: () {  },
                                            style:ButtonStyle(
                                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),side: BorderSide(color:Color(0xff00734E), ), ))    ,

                                            ),
                                            child: Text("Save",style: TextStyle(color:Color(0xff00734E),fontSize: 16),),

                                          ) ,
                                        ),
                                      ],
                                    ),

                                  ],
                                ),
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        )


    );

  }
}

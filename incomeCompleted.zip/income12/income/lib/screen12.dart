
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/widgets.dart';
import 'package:flutter_toggle_tab/flutter_toggle_tab.dart';
import 'package:flutter/material.dart';
import 'main.dart';
import 'screen2.dart';
import 'Card.dart';

class pay extends StatefulWidget {

  pay({Key? key,required this.l,required this.id}) : super(key: key);

  final lis2 l;
  final String id;
  @override
  State<pay> createState() => _MyHomePageState(sd:l,id: id);
}

class _MyHomePageState extends State<pay> {

  _MyHomePageState({Key? key,required this.sd,required this.id});
  final String id;
  final lis2 sd;
  bool viewlist=true;
  var slct=-1;
  var radiocolor1=[Colors.black54,Colors.black54];
  @override
  Widget build(BuildContext context) {
    lis2 list = sd;



    return Scaffold(
        body: Center(
          // Center is a layout widget. It takes a single child and positions it
          // in the middle of the parent.
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(height: 20,),
                SizedBox(
                  height: MediaQuery.of(context).size.height*0.17,

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children:  [
                      IconButton(onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()  ),);  }, icon: Icon(Icons.arrow_back,color: Colors.white,)),
                      Text("Transaction details",style: TextStyle(fontSize: 20,color: Colors.white),),
                      IconButton(onPressed: null, icon: Icon(Icons.notifications_none,color: Colors.white,))
                    ],
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height*0.8,

                  width: MediaQuery.of(context).size.width,
                  child: Container(
                    decoration:  const BoxDecoration(
                      borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10)),
                      color: Colors.white,
                    ),

                    child: Column(

                      children: [
                        SizedBox(height: 30,),
                        Row(
                          children: [
                            SizedBox(width: 20,),
                            Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(30)),
                                  color: Colors.black12,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(15.0),
                                  child: Image.network(list.icon,width: 30,height: 30,),
                                )),
                            SizedBox(width: 20,),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(list.title,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 22),),
                                Text(list.subtitle,style: TextStyle(color: Colors.black54),)
                              ],
                            )
                          ],
                        ),
                        SizedBox(height: 20,),
                        Container(
                          width: MediaQuery.of(context).size.width*0.96,
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Price",style: TextStyle(fontSize: 20,color: Colors.black54),),
                                    Text("\$ "+(list.mod*0.9).toString(),style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                                  ],
                                ),
                                SizedBox(height: 10,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Fee",style: TextStyle(fontSize: 20,color: Colors.black54),),
                                    Text("\$ "+(list.mod*0.1).toString(),style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                                  ],
                                ),
                                SizedBox(height: 10,),
                                Divider(),
                                SizedBox(height: 10,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Total",style: TextStyle(fontSize: 20,color: Colors.black54),),
                                    Text("\$ "+(list.mod).toString(),style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          child: Column(
                            children: [
                              InkWell(
                                onTap: (){
                                  setState(() {
                                    slct=0;
                                    radiocolor1=[Color(0xff00734E),Colors.black54];
                                  });
                                },
                                child: Container(
                                  width: MediaQuery.of(context).size.width*0.82,
                                  height: 100,
                                  decoration:BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.circular(20)),
                                    color: Colors.black12,
                                  ) ,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          const SizedBox(width: 30,),
                                          Container(
                                              decoration: const BoxDecoration(
                                                color: Colors.white,
                                                shape: BoxShape.circle
                                              ),
                                              child: Padding(
                                                padding: const EdgeInsets.all(8.0),
                                                child: Icon(Icons.paypal_rounded,size: 50,color: radiocolor1[0],),
                                              )),
                                          SizedBox(width: 10,),
                                          Text("Paypal",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: radiocolor1[0]),),
                                        ],
                                      ),

                                      Row(
                                        children: [
                                          Transform.scale(
                                            scale: 1.5,
                                            child: Radio(value: 0,

                                                activeColor: Color(0xff00734E),
                                                groupValue: slct, onChanged: (int? value){
                                                    setState(() {
                                                      slct = value!;
                                                      radiocolor1=[Color(0xff00734E),Colors.black54];
                                                    });
                                            }),
                                          ),
                                          SizedBox(width: 10,)
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              InkWell(
                                onTap: (){
                                  setState(() {
                                    slct=1;
                                    radiocolor1=[Colors.black54,Color(0xff00734E)];
                                  });
                                },
                                child: Container(
                                  width: MediaQuery.of(context).size.width*0.82,
                                  height: 100,
                                  decoration:BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.circular(20)),
                                    color: Colors.black12,
                                  ) ,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          SizedBox(width: 30,),
                                          Container(
                                              decoration:BoxDecoration(
                                                color: Colors.white,
                                                shape: BoxShape.circle,
                                              ) ,
                                              child: Padding(
                                                padding: const EdgeInsets.all(8.0),
                                                child: Icon(Icons.credit_card,size: 50,color: radiocolor1[1],),
                                              )),
                                          SizedBox(width: 10,),
                                          Text("Debit Card",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: radiocolor1[1],)),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Transform.scale(
                                            scale: 1.5,
                                            child: Radio(onChanged: (int? value) {
                                              setState(() {
                                                slct=value!;
                                                radiocolor1=[Colors.black54,Color(0xff00734E)];
                                              });
                                            },
                                              value: 1,
                                              activeColor: Color(0xff00734E),
                                              groupValue:slct ,),
                                          ),
                                          SizedBox(width: 10,)
                                        ],
                                      ),


                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: 20,),
                        Container(
                          width: MediaQuery.of(context).size.width*0.86,

                          child: OutlinedButton(
                            onPressed: () {

                              lis2 q=list;
                              q.mod=q.mod*(-1);
                              print(q.mod.toString());
                              FirebaseFirestore.instance.collection("Transactions").add(q.toJson());
                              print(id);
                              var db=FirebaseFirestore.instance;
                              final sfDocRef = db.collection("ttl").doc("total");
                              db.runTransaction((transaction) async {
                                final snapshot = await transaction.get(sfDocRef);
                                // Note: this could be done without a transaction
                                //       by updating the population using FieldValue.increment()
                                final newBalance = snapshot.get("balance") +list.mod ;
                                transaction.update(sfDocRef, {"balance": newBalance});
                              }).then(
                                    (value) => print("DocumentSnapshot successfully updated!"),
                                onError: (e) => print("Error updating document $e"),
                              );
                              db.collection("bills").doc(id).delete().then(
                                    (doc){
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        duration: Duration(seconds: 1),
                                        content: Text("Successfully paid",style: TextStyle(color: Colors.black,fontSize: 18,),),
                                        backgroundColor: Color(0xff00734E),
                                      ));
                                    },
                                onError: (e) => print("Sorry try agian later"),

                              );
                            },
                            style:ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(Color(0xff00734E)),
                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),side: BorderSide(color:Color(0xff00734E), ), ))    ,

                            ),
                            child: Text("Pay Now",style: TextStyle(color:Colors.white,fontSize: 25),),

                          ) ,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        )


    );

  }



}

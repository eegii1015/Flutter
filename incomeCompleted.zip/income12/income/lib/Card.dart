
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';
import 'package:flutter_credit_card/credit_card_brand.dart';
import 'package:flutter_credit_card/credit_card_form.dart';
import 'package:flutter_credit_card/credit_card_model.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';
import 'package:income/main.dart';
class Crd {
  String name;
  String cardno;
  String cvc;
  String exp_date;
  String val_date;
  Crd(this.name,this.cardno,this.cvc,this.exp_date,this.val_date);
}
Widget Recipe(lis1 list,BuildContext context){
  var tot=(list.mod<0)?(list.mod*(-1)):(list.mod);
  return SingleChildScrollView(
    child: Container(
      width: MediaQuery.of(context).size.width*0.9,
      child: Column(
        children: [
          SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Staus:"),
              Text((list.mod<0)?"Expence":"Income",style: TextStyle(color: (list.mod<0)?Colors.redAccent:Colors.green,),),
            ],
          ),
          SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("From"),
              Text(list.title,style: TextStyle(fontWeight: FontWeight.bold,),),

            ],
          ),
          SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Time:"),
              Text(list.mod.toString(),style: TextStyle(fontWeight: FontWeight.bold,),),
            ],
          ),
          SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Date"),
              Text(list.subtitle,style: TextStyle(fontWeight: FontWeight.bold,),),
            ],
          ),
          SizedBox(height: 15,),
          Divider(),
          SizedBox(height: 15,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Earnings:"),
              Text((tot*1.1).toInt().toString(),style: TextStyle(fontWeight: FontWeight.bold,),)

            ],
          ),
          SizedBox(height: 20,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Fee"),
              Text((tot*(-0.1)).toString(),style: TextStyle(fontWeight: FontWeight.bold,),),
            ],
          ),
          SizedBox(height: 15,),
          Divider(),
          SizedBox(height: 15,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Total:"),
              Text(tot.toString(),style: TextStyle(fontWeight: FontWeight.bold,),),
            ],
          )

        ],
      ),
    ),
  );
}


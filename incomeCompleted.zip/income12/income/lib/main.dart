

import 'dart:math';
import 'package:flutter/services.dart';

import 'screen11.dart';
import 'package:flutter_toggle_tab/flutter_toggle_tab.dart';
import 'package:flutter/material.dart';
import 'screen12.dart';
import 'screen2.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
var month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov", "Dec"];
class lis1 {
  String icon;
  String title;
  String subtitle;
  int mod;
  lis1(this.icon,this.title,this.subtitle,this.mod);
  factory lis1.fromJson(Map<String, dynamic> json){ return lis1(json['icon'], json['title'], json['subtitle'], json['value'],);
  }
  toJson() {
    return{'icon': this.icon, 'title': this.title, 'subtitle': this.subtitle, 'value': this.mod};
  }

}
class lis2 {
  String icon;
  String title;
  String subtitle;
  int mod;
  lis2(this.icon,this.title,this.subtitle,this.mod);
  factory lis2.fromJson(Map<String, dynamic> json){ return lis2(json['icon'], json['title'], json['subtitle'], json['value'],);
  }
  toJson() {
    return{'icon': this.icon, 'title': this.title, 'subtitle': this.subtitle, 'value': this.mod};
  }
}
void main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  MyApp({Key? key}) : super(key: key);




  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter app',
      theme: ThemeData(

        scaffoldBackgroundColor: Color(0xff00734E),
        primarySwatch: Colors.blue,

      ),
      home: MyHomePage9(title: 'Flutter Demo Home Page'),

    );
  }
}

class MyHomePage9 extends StatefulWidget {
  const MyHomePage9({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage9> createState() => MyHomePageState1();
}
class money{
  int value;
  money(this.value);
  factory money.parse(Map<String, dynamic> json){
    var s=json['balance'];
    return money(s);
  }
}


/**
 *
 *
 *
 *
 *
 *
 *
 */
class MyHomePageState1 extends State<MyHomePage9> {


  bool lst=true;
  Widget ListB1(lis1 i){
    try{
      var col;
      var pre="";
      var s;
      if(i.mod<0){
        s=i.mod*(-1);
        col=Colors.red ;
        pre="- \$";
      }
      else{
        s=i.mod;
        col=Colors.green ;
        pre="+ \$";
      }

      return Column(
        children: [
          InkWell(
            onTap: (){
              //Navigator.push(context, MaterialPageRoute(builder: (context) => detail1(list: i)  ),);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => det(l: i),),);
            },

            child: Container(

              height: 50,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image.network(i.icon,width: 40,height: 40,),
                      Container(
                        width: MediaQuery.of(context).size.width*0.3,

                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(i.title.toString(),style: TextStyle(fontSize: 18,color: Colors.black),),
                            Text(i.subtitle.toString(),style: TextStyle(fontSize: 12,color: Colors.black54),)
                          ],),
                      ),
                      SizedBox(
                          width: MediaQuery.of(context).size.width*0.23,
                          child: Text(pre+s.toString(),style:TextStyle(color: col,fontSize: 23),)),
                    ],
                  ),

                ],
              ),),
          ),
          Divider(),
        ],
      );
    }on Exception catch(err){
      return Text("Error");
    }

    }

  Widget ListB2(lis2 i,String id){
    try{
      return Column(
        children: [
          Container(

            height: 50,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.network(i.icon,width: 40,height: 40,),
                Container(
                  width: MediaQuery.of(context).size.width*0.3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,

                    children: [
                      Text(i.title.toString(),style: TextStyle(fontSize: 18,color: Colors.black),),
                      Text(i.subtitle.toString(),style: TextStyle(fontSize: 12,color: Colors.black54),)
                    ],),
                ),
                OutlinedButton(
                    onPressed: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => pay(l: i,id: id),),); },
                    style:ButtonStyle(
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),side: BorderSide(color:Color(0xff00734E), ), ))    ,

                    ),
                    child: Text("Pay",
                      style: TextStyle(fontSize: 19,color: Colors.green),
                    )
                )
                ,
              ],
            ),),
          Divider(),
        ],
      );
    } on Exception catch(err){
      return Text("Error");
    }
  }
  Widget visiblitycontrol(BuildContext context,bool v,List a,List b,List c){
    if (a == null && a.length == 0) {
      return Text("empa"); // You can safely access the element here.
    }
    if (b == null && b.length == 0) {
      return Text("empb"); // You can safely access the element here.
    }
    if (c == null && c.length == 0) {
      return Text("empb"); // You can safely access the element here.
    }

    try{
      return Visibility(
        visible: v,
        child: ListView.builder(
          itemCount: a.length,
          itemBuilder: (context,index){
            return ListB1(a[index]); },

        ),

        replacement: ListView.builder(
          itemCount: b.length,
          itemBuilder: (context,index){return ListB2(b[index],c[index]); },

        ),
      );
    }on Exception catch(err){
      return Text("alddaa");
    }
  }
  var ind=0;
  //var sup1=[new lis1("https://cdn-icons-png.flaticon.com/512/1384/1384060.png","Youtube", "Today", 850),new lis1("https://cdn-icons-png.flaticon.com/512/25/25180.png", "Bitcoin", "Yesterday", 100),new lis1("https://cdn-icons-png.flaticon.com/512/483/483497.png", "Gas", 'Jan 30, 2022', -20)];
  //var sup2=[new lis2("https://cdn-icons-png.flaticon.com/512/252/252851.png","Electricity", "Feb 28, 2022",50),new lis2("https://cdn-icons-png.flaticon.com/512/1946/1946436.png", "House Rent", 'Mar 28, 2022',50),new lis2("https://cdn-icons-png.flaticon.com/512/2111/2111685.png", "Spotify", "Mar 31, 2022",20)];
  var total=0;
  var trans=[];
  var bills=[];
  var id=[];
@override
  void initState() {
    setState(() {
        var db=FirebaseFirestore.instance;
        db.collection("Transactions").get().then((val){
          trans=[];
          for(var i in val.docs){

            //print(i.data());
            trans.add(lis1.fromJson(i.data()));

          }
        });
        var w=db.collection("ttl");
        w.get().then((val) {
          total=money.parse(val.docs[0].data()).value;
        },
            onError: (err)=>print("Error")
        );

        db.collection("bills").get().then((value){
          bills=[];
          id=[];
          for(var i in value.docs){
            id.add(i.id);
            //print(i.data().runtimeType);
            bills.add(lis2.fromJson(i.data()));
          }
        });


    });

    super.initState();
  }

  @override
  build(BuildContext context){
  setState(() {
    var db=FirebaseFirestore.instance;
    db.collection("Transactions").get().then((val){
      trans.clear();
      for(var i in val.docs){

        //print(i.data());
        trans.add(lis1.fromJson(i.data()));

      }
    });
    var w=db.collection("ttl");
    w.get().then((val) {
      total=money.parse(val.docs[0].data()).value;
    },
        onError: (err)=>print("Error")
    );

    db.collection("bills").get().then((value){
      bills.clear();
      id.clear();
      for(var i in value.docs){
        id.add(i.id);
        //print(i.data().runtimeType);
        bills.add(lis2.fromJson(i.data()));
      }
    });
  });


    return Scaffold(
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height*0.18,

              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children:  [
                    IconButton(onPressed: null, icon: Icon(Icons.arrow_back,color: Colors.white,)),
                    Text("Wallet",style: TextStyle(fontSize: 20,color: Colors.white),),
                    IconButton(onPressed: null, icon: Icon(Icons.notifications_none,color: Colors.white,))
                  ],
              ),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height*0.82,

              child: SingleChildScrollView(
                child: Container(
                  decoration:  const BoxDecoration(
                    borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10)),
                    color: Colors.white,
                  ),

                  child: Column(

                    children: [

                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          SizedBox(height:30 ,),
                          Text('Total Balance',style: TextStyle(fontSize: 15,color: Colors.black87),)
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children:  [
                          Text("\$"+total.toString(),style: TextStyle(fontSize: 25,color: Colors.black),)
                        ],
                      ),
                      const SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Column(
                            children: const <Widget>[
                              IconButton(onPressed: null, icon: Icon(Icons.add)),
                              Text('Add')
                            ],
                          ),
                          Column(
                            children: [
                              IconButton(onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>screen2()  ),);  }, icon: Icon(Icons.paypal)),
                              Text('Pay'),
                            ],
                          ),
                          Column(children: [
                            IconButton(onPressed: (){   }, icon: Icon(Icons.send)),
                            Text('Send')
                          ],)
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width,
                            child: FlutterToggleTab(
                                borderRadius: 30,
                                unSelectedBackgroundColors: const [Colors.white54],
                                height: 50,
                                marginSelected:  const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                                isShadowEnable: true,
                                selectedIndex: ind,
                                selectedBackgroundColors: const [Colors.white30],
                                labels:  const ['Transactions','Upcoming Bills'],
                                selectedLabelIndex: (index){
                                  setState(() {
                                    ind=index;
                                    (index==0)?lst=true:lst=false;
                                  });
                                },
                                selectedTextStyle: const TextStyle(color: Colors.black),
                                unSelectedTextStyle: const TextStyle(color: Colors.black),

                                ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children:  [
                          Container(
                            decoration: const BoxDecoration(color: Colors.white,),
                            width: MediaQuery.of(context).size.width*0.95,
                            height: MediaQuery.of(context).size.height*0.55,
                            child: Visibility(
                              visible: lst,
                              child: ListView.builder(
                                itemCount: trans.length,
                                itemBuilder: (context,index){
                                  return ListB1(trans[index]); },

                              ),

                              replacement: ListView.builder(
                                itemCount: bills.length,
                                itemBuilder: (context,index){return ListB2(bills[index],id[index]); },

                              ),
                            )
                          ),
                        ],
                      ),
                      Row(),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      )


    );

  }
}

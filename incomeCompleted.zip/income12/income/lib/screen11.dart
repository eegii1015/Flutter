
import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:flutter_toggle_tab/flutter_toggle_tab.dart';
import 'package:flutter/material.dart';
import 'main.dart';
import 'screen2.dart';
import 'Card.dart';
/*
void main() {
  runApp(   detail1(),
  );
}

class detail1 extends StatelessWidget {

  detail1({Key? key}) : super(key: key);


  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter app',
      theme: ThemeData(
        scaffoldBackgroundColor: Color(0xff00734E),
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(key: key,title: 'Flutter Demo Home Page',),
    );
  }
}
*/
class det extends StatefulWidget {

  det({Key? key,required this.l}) : super(key: key);

  final lis1 l;
  @override
  State<det> createState() => _MyHomePageState(sd:l);
}

class _MyHomePageState extends State<det> {
//class detail1 extends StatelessWidget {
  //detail1({Key? key, required this.list}) : super(key: key);
  _MyHomePageState({Key? key,required this.sd});// : super(key: key);
  final lis1 sd;
  bool viewlist=true;
  @override
  Widget build(BuildContext context) {
  lis1 list = sd;
  var tot=(list.mod<0)?(list.mod*(-1)):(list.mod);


  return Scaffold(
        body: Center(
          // Center is a layout widget. It takes a single child and positions it
          // in the middle of the parent.
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(height: 20,),
                SizedBox(
                  height: MediaQuery.of(context).size.height*0.17,

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children:  [
                      IconButton(onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()  ),);
                      }, icon: Icon(Icons.arrow_back,color: Colors.white,)),
                      Text("Transaction details",style: TextStyle(fontSize: 20,color: Colors.white),),
                      IconButton(onPressed: null, icon: Icon(Icons.notifications_none,color: Colors.white,))
                    ],
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height*0.8,

                  width: MediaQuery.of(context).size.width,
                  child: Container(
                    decoration:  const BoxDecoration(
                      borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10)),
                      color: Colors.white,
                    ),

                    child: Column(

                      children: [
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          height: 70,
                          width: 70,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.black12,
                          ),
                          child: Image.network(list.icon,width: 40,height: 40,),
                        ),
                          SizedBox(height: 20,),
                        Container(

                          decoration: BoxDecoration(
                              color:(list.mod<0)?Colors.redAccent:Colors.green,

                              borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                          child: Padding(
                              padding: EdgeInsets.symmetric( vertical: 5,horizontal: 10),
                              child: Text((list.mod<0)?"Expence":"Income",style: TextStyle(fontSize: 20,),)),
                        ),
                        SizedBox(height: 20,),
                        Text("\$"+tot.toString(),style: TextStyle(fontWeight: FontWeight.bold,fontSize: 30),),
                        SizedBox(height: 20,),
                        InkWell(
                          onTap: (){
                            setState(() {
                              viewlist=!viewlist;
                            });

                          },
                          child: Container(
                            height: 30,
                            width: MediaQuery.of(context).size.width*0.9,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Transaction details",style: TextStyle(),),
                                Icon(viewlist?Icons.arrow_upward:Icons.arrow_downward),
                              ],
                            ),
                          ),
                        ),
                        Visibility(
                          visible: viewlist,
                          child: Recipe(list,context),
                        ),
                        SizedBox(height: viewlist?20:60,),
                        Container(
                          width: MediaQuery.of(context).size.width*0.85,
                          child: OutlinedButton(
                            onPressed: (){
                              showModalBottomSheet(context: context, builder:(context){
                                return Container(
                                  width: MediaQuery.of(context).size.width*0.98,
                                    height: MediaQuery.of(context).size.width*0.7,
                                    child: Padding(
                                        padding: EdgeInsets.all(20),
                                        child: SingleChildScrollView(child: Recipe(list, context))));
                              });
                            },
                            child: Text("Print Recipe",style: TextStyle(color:Color(0xff00734E),fontSize: 18 ),),
                            style:ButtonStyle(
                              shape: MaterialStateProperty.all<RoundedRectangleBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),side: BorderSide(color:Color(0xff00734E),width: 2 ), ))    ,

                            ),
                          ),
                        )

                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        )


    );

  }



}
